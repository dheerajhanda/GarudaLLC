/*Easy Slider*/
$(function(){
    $('#slider img:gt(0)').hide();
    setInterval(function(){
      $('#slider :first-child').fadeOut(0)
         .next('img').fadeIn(0)
         .end().appendTo('#slider');}, 
      3000);
});

/*Elastic GoTo*/
$('.button a').each(function(){
	var goto = $(this).attr('href');
	$(this).removeAttr('href').click(function() {
		$('html, body').animate({
		scrollTop: $(goto).offset().top
	}, 650); });
});

/*Menu Slider*/
$(document).ready(function () {
	cchild = $("#box-container div").size()
	cwidth = (cchild*320)+"px";
	$("#box-container").css("width", cwidth);

    $("#box-container div:first").addClass("current");
    $("#back").hide();
	
    $("#back").click(function () {
        $(".current").prev('div').addClass("current").next('div').removeClass("current");
        if ($("#box-container div:first").hasClass("current")) {
            $("#back").fadeOut(0);
        }
        if ("#box-container div:last-child:not(.current)") {
            $("#next").fadeIn(0);
        }
        $("#box-container").animate({
            marginLeft: "+=320px"
        }, 400);
        event.preventDefault();
    });
	
    $("#next").click(function () {
        $(".current").next('div').addClass("current").prev('div').removeClass("current");
        if ("#box-container div:first:not(.current)") {
            $("#back").fadeIn(0);
        }
        if ($("#box-container div:last-child").hasClass("current")) {
            $("#next").fadeOut(0);
        }
        $("#box-container").animate({
            marginLeft: "-=320px"
        }, 400);
        event.preventDefault();
    });
});

/*Validation Rules*/
$('fieldset *').each(function(){
	var default_value = $(this).val();
	$(this).focus(function(){
		if ($(this).val() == default_value) $(this).val("").addClass('current');
	});
	$(this).blur(function(){
		if ($(this).val() == "") $(this).val(default_value).removeClass('current');
	});
});
$(document).ready(function() {
var validator = $("form").validate({ 
	 	rules: {
			email: { 
				required: true, 
				email: true
			},
			comment: { 
				required: true
			}
		}, 
		errorPlacement: function(error, element) { 
		error.appendTo(element.parent() );
		}
	});
});